from problema import *
from scipy.optimize import minimize


bounds = c_[pesos_iniciais[:2, :].ravel(), pesos_iniciais[:2, :].ravel()].tolist() + [[-1.0,1.0]] * (2 * (n - 2))
P1 = minimize(funcao_objetivo, pesos_iniciais.ravel(),method=["L-BFGS-B","TNC","SLSQP"][0],options={'disp': False},bounds=bounds).x.reshape((-1, 2),)
exato = funcao_objetivo(P1)
#print(P1)
#print(exato)
show_bar(P1)
savefig("classico.png")
savetxt('classico.csv', P1, delimiter=',',header='x,y')
