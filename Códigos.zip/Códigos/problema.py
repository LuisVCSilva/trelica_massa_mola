from numpy import *
from scipy.constants import g
from matplotlib.pyplot import *

m = .1    # massa sobre a estrutura (kg)
n = 20    # qtde de vertices/massas
e = .1    # Distancias inicial entre vertices
l = e     # comprimento das molas em situacoes sem deformacao
k = 10000 # constante de rigidez da mola

pesos_iniciais = zeros((n, 2))
pesos_iniciais[:, 0] = repeat(e * arange(n // 2), 2)
pesos_iniciais[:, 1] = tile((0, -e), n // 2)

A = eye(n, n, 1) + eye(n, n, 2)

L = l * (eye(n, n, 1) + eye(n, n, 2))
for i in range(n // 2 - 1):
    L[2 * i + 1, 2 * i + 2] *= sqrt(2)

I, J = nonzero(A)

distancias = lambda P: sqrt((P[:, 0] - P[:, 0][:, newaxis])**2 +
                         (P[:, 1] - P[:, 1][:, newaxis])**2)


def spring_color_map(c):
    min_c, max_c = -0.00635369422326, 0.00836362559722
    ratio = (max_c - c) / (max_c - min_c)
    color = cm.coolwarm(ratio)
    shading = sqrt(abs(ratio - 0.5) * 2)
    return (0.0,0.0,0.0)#(shading * color[0], shading * color[1], shading * color[2], color[3])


def show_bar(P):
    figure(figsize=(5, 4))
    # Wall.
    axvline(0, color='k', lw=3)
    # distanciasance matrix.
    D = distancias(P)
    # We plot the springs.
    for i, j in zip(I, J):
        # The color depends on the spring tension, which
        # is proportional to the spring elongation.
        c = D[i, j] - L[i, j]
        plot(P[[i, j], 0], P[[i, j], 1],
                 lw=2, color=cm.copper(c*150))
    # We plot the masses.
    plot(P[[I, J], 0], P[[I, J], 1], 'ok',)
    # We configure the axes.
    axis('equal')
    xlim(P[:, 0].min() - e / 2, P[:, 0].max() + e / 2)
    ylim(P[:, 1].min() - e / 2, P[:, 1].max() + e / 2)
    xticks([])
    yticks([])
    title("f(min) = " + str(funcao_objetivo(P)))

def funcao_objetivo(P):
    # Matriz de pesos
    P = P.reshape((-1, 2))

    # Matriz de Distancias
    D = distancias(P)

    # Energia potencial total = energia gravitacional + energia elastica
    return (m * g * P[:, 1].sum() + 0.5 * (k * A * (D - L)**2).sum())
